# File Transfer

Multi threaded client/server file transfer over local network.

![alt text](https://github.com/AminAliari/File-Transfer/blob/master/screenshot.png)
